/*
 *   Copyright (C) 2022 GeorgH93
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package at.pcgamingfreaks.Bukkit.Protocol;

import at.pcgamingfreaks.Bukkit.Util.IUtils;

import net.minecraft.network.chat.ChatType;
import net.minecraft.network.chat.Component;
//import net.minecraft.network.protocol.game.ClientboundPlayerChatPacket; //TODO add support
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;

import org.jetbrains.annotations.NotNull;

import java.util.UUID;

/*
 * NOTE: Generated code !! DO NOT EDIT !!
 * Reference: https://freemarker.apache.org/
 * See template: ChatMessagePacketFactoryNms.ftl
 */
public final class ChatMessagePacketFactory_1_19_R3 implements IChatMessagePacketFactory
{
	@Override
	public Object makeChatPacket(final @NotNull String json, final @NotNull UUID sender)
	{
		return new ClientboundSystemChatPacket((Component) IUtils.INSTANCE.jsonToIChatComponent(json), false);
	}

	@Override
	public Object makeChatPacketSystem(final @NotNull String json)
	{
		return new ClientboundSystemChatPacket((Component) IUtils.INSTANCE.jsonToIChatComponent(json), false);
	}

	@Override
	public Object makeChatPacketActionBar(final @NotNull String json)
	{
		return new ClientboundSystemChatPacket((Component) IUtils.INSTANCE.jsonToIChatComponent(json), true);
	}
}