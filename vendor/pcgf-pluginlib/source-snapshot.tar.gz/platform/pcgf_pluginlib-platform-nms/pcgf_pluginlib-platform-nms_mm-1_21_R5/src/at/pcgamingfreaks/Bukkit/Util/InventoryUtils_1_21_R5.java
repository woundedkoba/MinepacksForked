/*
 *   Copyright (C) 2021 GeorgH93
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package at.pcgamingfreaks.Bukkit.Util;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.network.protocol.game.ClientboundOpenScreenPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.inventory.MenuType;

import org.bukkit.craftbukkit.v1_21_R5.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.logging.Logger;

/*
 * NOTE: Generated code !! DO NOT EDIT !!
 * Reference: https://freemarker.apache.org/
 * See template: InventoryUtilsNms.ftl
 */
public final class InventoryUtils_1_21_R5 implements IInventoryUtils
{
	@Override
	public String convertItemStackToJson(final @NotNull ItemStack itemStack, final @NotNull Logger logger)
	{
		net.minecraft.world.item.ItemStack stack = CraftItemStack.asNMSCopy(itemStack);
		Object base = net.minecraft.world.item.ItemStack.CODEC.encodeStart(MinecraftServer.getServer().registryAccess().createSerializationContext(net.minecraft.nbt.NbtOps.INSTANCE), stack).getOrThrow();
		return base.toString();
	}

	@Override
	public Object prepareTitleForUpdateInventoryTitle(final @NotNull String title)
	{
		return Component.literal(title);
	}

	@Override
	public void updateInventoryTitle(final @NotNull Player player, final @NotNull String newTitle)
	{
		updateInventoryTitlePrepared(player, prepareTitleForUpdateInventoryTitle(newTitle));
	}

	@Override
	public void updateInventoryTitlePrepared(final @NotNull Player player, final @NotNull Object newTitle)
	{
		InventoryView view = player.getOpenInventory();
		Inventory topInv = view.getTopInventory();
		if(topInv.getType() == InventoryType.CRAFTING) return;

		ServerPlayer entityPlayer = (ServerPlayer) IUtils.INSTANCE.getHandle(player);
		ClientboundOpenScreenPacket packet = new ClientboundOpenScreenPacket(entityPlayer.containerMenu.containerId, (MenuType<?>) InventoryTypeMapper_Reflection.getInvContainersObject(topInv), (Component) newTitle);
		entityPlayer.connection.send(packet);
		entityPlayer.containerMenu.sendAllDataToRemote();
	}

	@Override
	public Object prepareTitleForOpenInventoryWithCustomTitle(final @NotNull String title)
	{
		return prepareTitleForUpdateInventoryTitle(title);
	}

	@Override
	public void openInventoryWithCustomTitle(final @NotNull Player player, final @NotNull Inventory inventory, final @NotNull String title)
	{
		player.openInventory(inventory);
		updateInventoryTitle(player, title);
	}

	@Override
	public void openInventoryWithCustomTitlePrepared(final @NotNull Player player, final @NotNull Inventory inventory, final @NotNull Object title)
	{
		player.openInventory(inventory);
		updateInventoryTitlePrepared(player, title);
	}

	@Override
	public Object getInventoryTitle(final @NotNull Inventory inventory)
	{
		return null;
	}

	@Override
	public void setInventoryTitle(final @NotNull Inventory inventory, final @NotNull String newTitle)
	{
	}

	@Override
	public Object prepareTitleForSetInventoryTitle(@NotNull String title)
	{
		return null;
	}


	@Override
	public void setInventoryTitlePrepared(final @NotNull Inventory inventory, final @NotNull Object newTitle)
	{
	}

	@Override
	public @Nullable Inventory getClickedInventory(final @NotNull InventoryClickEvent event)
	{
		if (event.getRawSlot() < 0) return null;

		InventoryView view = event.getView();
		Inventory topInventory = view.getTopInventory();
		if (event.getRawSlot() < topInventory.getSize())
			return topInventory;
		else
			return view.getBottomInventory();
	}

	@Override
	public @Nullable Inventory getPlayerTopInventory(final @NotNull Player player)
	{
		InventoryView view = player.getOpenInventory();
		if(view == null) return null;
		return view.getTopInventory();
	}
}