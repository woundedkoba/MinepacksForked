/*
 *   Copyright (C) 2021 GeorgH93
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package at.pcgamingfreaks.Bukkit.Protocol;

import at.pcgamingfreaks.Bukkit.Util.IUtils;

import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;

import org.jetbrains.annotations.NotNull;

/*
 * NOTE: Generated code !! DO NOT EDIT !!
 * Reference: https://freemarker.apache.org/
 * See template: TitleMessagePacketFactoryNms.ftl
 */
public final class TitleMessagePacketFactory_1_21_R6 implements ITitleMessagePacketFactory
{
	@Override
	public Object makeTitlePacket(final @NotNull String json)
	{
		return new ClientboundSetTitleTextPacket((Component) IUtils.INSTANCE.jsonToIChatComponent(json));
	}

	@Override
	public Object makeSubTitlePacket(final @NotNull String json)
	{
		return new ClientboundSetSubtitleTextPacket((Component) IUtils.INSTANCE.jsonToIChatComponent(json));
	}

	@Override
	public Object makeTitlePacketTime(final int fadeIn, final int stay, final int fadeOut)
	{
		return new ClientboundSetTitlesAnimationPacket(fadeIn, stay, fadeOut);
	}

	@Override
	public Object makeTitlePacketActionBar(final @NotNull String json)
	{
		return new ClientboundSetActionBarTextPacket((Component) IUtils.INSTANCE.jsonToIChatComponent(json));
	}
}