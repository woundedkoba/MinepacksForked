/*
 *   Copyright (C) 2021 GeorgH93
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

package at.pcgamingfreaks.Bukkit.Util;

import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.server.level.ServerPlayer;

import org.bukkit.craftbukkit.v1_19_R2.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/*
 * NOTE: Generated code !! DO NOT EDIT !!
 * Reference: https://freemarker.apache.org/
 * See template: UtilsNms.ftl
 */
public final class Utils_1_19_R2 implements IUtils
{
	@Override
	public ServerPlayer getHandle(final @NotNull Player player)
	{
		return ((CraftPlayer) player).getHandle();
	}

	@Override
	public int getPing(final @NotNull Player player)
	{
		return player.getPing();
	}

	@Override
	public void sendPacket(final @NotNull Player player, final @NotNull Object packet)
	{
		getHandle(player).
			connection.send((Packet<?>) packet);
	}

	@Override
	public Object jsonToIChatComponent(@NotNull String json)
	{
		return Component.Serializer.fromJson(json);
	}
}