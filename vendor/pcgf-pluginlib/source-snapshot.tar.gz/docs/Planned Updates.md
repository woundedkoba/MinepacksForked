PCGF PluginLib Planned Updates
==============================

- Run a live Paper 26.3 runtime verification when a distributable server build is available.
- Add an integration-test matrix covering Paper 26.3 item restore for sticks, torches, counts, tools, enchantments, renamed items, components, old serialized formats, and malformed items.
- Verify normal PluginLib and shaded/standalone artifacts independently with `jar tf` and `javap`.
- Verify MinepacksForked restores representative existing backpacks and preserves the original database record when conversion fails.
- Keep the compatibility matrix, changelog, known issues, and release notes current with each NMS module addition.
