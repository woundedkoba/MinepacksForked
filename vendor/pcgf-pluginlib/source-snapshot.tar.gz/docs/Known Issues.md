PCGF PluginLib Known Issues
===========================

- The 26.3 module compiles against the available 26.2 mapped Spigot API because `org.spigotmc:spigot:26.3-R0.1-SNAPSHOT` is not published by the configured repositories. A live Paper 26.3 runtime test remains recommended.
- MinepacksForked is a downstream consumer and must be verified without modifying its source. Database restore testing should cover both SQLite and MySQL-shaped backups.
- Generic reflection fallback code still contains legacy conversion logic for older server families. It is not used by the generated 26.2+ serializers and should not be removed without testing all legacy versions.
