PCGF PluginLib Change Log
=========================

## 0.0.1

- Added explicit Minecraft 26.3 / `MC_NMS_26_3_R1` version support.
- Added the `pcgf_pluginlib-platform-nms-26_3_R1` Maven module and standalone plugin dependency.
- Updated 26.2+ generated NBT item deserializers to use Paper's public `CraftItemStack.asCraftMirror(nmsStack.copy())` conversion path.
- Removed the reflective `CraftItemStack.asBukkitCopy(net.minecraft.world.item.ItemStack)` conversion from the 26.2+ generated serializer path.
- Preserved existing NBT formats, old-format migration, and DataFixer upgrades.
- Added regression coverage for Minecraft 26.3 version metadata and server-version lookup.
- Removed the obsolete MVdWPlaceholderAPI integration and its unavailable repository dependency; PlaceholderAPI remains supported.

## Compatibility notes

Paper 26.2 changed the visibility and overloads of `CraftItemStack` conversion methods. The generated 26.2 and 26.3 serializers therefore convert decoded NMS stacks through `asCraftMirror` after copying the stack, preserving counts, components, names, enchantments, and other item metadata.

This fork uses stable fork version `0.0.1`; it does not publish snapshot coordinates.
